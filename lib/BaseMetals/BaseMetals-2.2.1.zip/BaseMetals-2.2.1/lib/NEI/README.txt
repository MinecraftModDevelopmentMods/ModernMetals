The following files are included for development purposes only and are not intended for distribution:
CodeChickenCore-*.*-*.*.*.*-dev.jar
NotEnoughItems-*.*-*.*.*.*-dev.jar
